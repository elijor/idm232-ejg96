<?php
    consoleMsg("env.php file LOADED yuh!");

    //specific to the current environment

    $domain = $_SERVER['HTTP_HOST'];

    consoleMsg("Domain is $domain");


    if ($domain == 'localhost:888') {
      $APP_CONFIG = [
        'environment' => 'local',
        'site_url' => 'http://localhost:8888/',
        'database_host' => 'localhost',
        'database_user' => 'root',
        'database_pass' => 'root',
        'database_name' => 'idm232',
      ];
    } else {
      $APP_CONFIG = [
        'environment' => 'live',
        'site_url' => 'https://www.elijgoldberg/',
        'database_host' => 'myslq.elijgoldberg.com',
        'database_user' => 'elijgcooking',
        'database_pass' => 'nowaydudebrohaha',
        'database_name' => 'idm232_ejg96',
      ];
    }


?>